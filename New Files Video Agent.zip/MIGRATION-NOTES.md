# Migration: Multi-Format Support

## Status
✅ Generator unterstützt jetzt BEIDE Content-Agent-Formate:

1. **Legacy Single-Lesson Format** (`examples/module04-lesson02.md`)
   - Eine Lektion pro Datei
   - Englische Überschriften (`# Lesson Title`, `# Learning Objectives`, …)
   - Unstrukturierte Bullets in `# Slide Summary`
   - Narration als Fließtext in `# Voice Narration Script`

2. **Module Format** (`modul-01-defi-grundlagen-FINAL.md`)
   - Mehrere Lektionen pro Datei
   - Deutsche Überschriften (`## Lektion X.Y`, `### Folien-Zusammenfassung`, …)
   - Explizite `**[Slide N] — Titel**`-Marker
   - 1:1-Zuordnung zwischen Slide und Narration

## Neue Dateien

- `src/module-parser.js`    — Parser für das Module Format
- `src/format-detector.js`  — Erkennt automatisch, welches Format vorliegt
- `src/normalize-lesson.js` — Bringt beide Parser-Outputs auf einheitliches Schema

## Geänderte Dateien

- `src/pipeline.js`       — Nutzt `parseAuto` statt `parseLesson`; neue Funktion `runPipelineForModule`
- `src/section-mapper.js` — Zwei Pfade: `mapDirectSlides` (neu) und `mapLegacySections` (alt)
- `src/cli.js`            — Neues Flag `--all-lessons` für Module-Batch

## CLI-Nutzung

Legacy (weiter unverändert):
```bash
node src/cli.js --input lesson.md --out ./output --style ../video-style-engine
```

Neu — Einzelne Lektion aus einem Modul:
```bash
node src/cli.js --input modul-01.md --lesson 3 --out ./output --style ../video-style-engine
```

Neu — Alle Lektionen eines Moduls in einem Rutsch:
```bash
node src/cli.js --input modul-01.md --all-lessons --out ./output --style ../video-style-engine
```

## Tests

- `node tests/run-tests.js` — Alle 8 Original-Tests grün (Regression)
- Manuelle Tests: 7 Lektionen erfolgreich durch den Generator (1 Legacy + 6 Modul-Format)

## Bekannte Einschränkungen

Die alte keyword-basierte Heuristik (`SECTION_KEYWORDS`) in `mapLegacySections`
existiert weiterhin als Fallback. Sie wird nur aufgerufen, wenn ein
Lesson-Objekt keine strukturierten `slides[]` hat — was nach der
Normalisierung nie der Fall ist. De-facto läuft jetzt immer der
`mapDirectSlides`-Pfad. Die Legacy-Heuristik bleibt als Sicherheit
bestehen, kann aber in einer künftigen Aufräum-Runde entfernt werden.
